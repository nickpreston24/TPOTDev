if (document.getElementById("TPOT_APP") != null) {
  setTimeout(function() {
    start();
  }, 500); // Give the HTML time to load
}

function start() {
  assignEventListeners();

}

var port = chrome.runtime.connect();

function assignEventListeners() {
  document.getElementById("btn_refresh").addEventListener("click",
    function() {
      window.postMessage({
        type: "FROM_APP",
        text: "refresh"
      }, "*");
    }, false);

  // window.onmessage = function(event) {
  //   console.log(event.data)
  // };

}


window.addEventListener("message", function(event) {
  // We only accept messages from ourselves
  if (event.source != window)
    return;

  if (event.data.type && (event.data.type == "FROM_CONTENT")) {
    console.log("[MSG] app.js : " + event.data.text);
    if (event.data.text == "insert") {
      alert("INSERTED");
      console.log("INSERTED");
    }
    // port.postMessage("Refreshed the Page");
  }
}, false);




// chrome.runtime.onConnect.addListener(function(port) {
//   console.assert(port.name == "knockknock");
//   port.onMessage.addListener(function(msg) {
//     console.log(msg)
//     // if (msg == "refresh")
//     //   port.postMessage("REFRESHING");
//     // alert("refresh Page!");
//   });
// });

// window.addEventListener("message", function(event) {
//   // We only accept messages from ourselves
//   if (event.source != window)
//     return;
//
//   if (event.data.type && (event.data.type == "FROM_APP")) {
//     console.log("[MSG] app.js : " + event.data.text);
//     if (event.data.text == "refresh") {
//       test();
//     }
//     port.postMessage("Refreshed the Page");
//   }
// }, false);







// document.getElementById("btn_refresh").addEventListener("click", function() {
//   alert("THIS IS APP.JS");
// });

// alert("THISDAFDSFAasDPP.JS");

// $("#btn_refresh").click(function() {
//   alert("THIS IS APP.JS");
// });
//
// var app = document.createElement("div");
// app.id = "TPOT_APP";
// app.setAttribute("w3-include-html", chrome.extension.getURL('app.html'));
// $("body").prepend(app);
