/////////////////////////////////////////
//             content.js              //
/////////////////////////////////////////
//  • Loaded on every tab on refresh   //
//  • Get commands from background.js  //
//  • Toggle / Attach / Refresh app    //
//  • Float app frame left or right    //
//  • Start with Chrome option         //
//  •                                  //
/////////////////////////////////////////

// var port = chrome.runtime.connect();
//
// chrome.runtime.onConnect.addListener(function(port) {
//   console.assert(port.name == "knockknock");
//   port.onMessage.addListener(function(msg) {
//     if (msg == "refresh")
//       port.postMessage("REFRESHING");
//     alert("refresh Page!");
//   });
// });

// function assignEventListeners() {
//   document.getElementById("btn_refresh").addEventListener("click",
//     function() {
//       window.postMessage({
//         type: "FROM_APP",
//         text: "refresh"
//       }, "*");
//     }, false);
//
//   // window.onmessage = function(event) {
//   //   console.log(event.data)
//   // };
//
// }

var port = chrome.runtime.connect();

window.addEventListener("message", function(event) {
  // We only accept messages from ourselves
  if (event.source != window)
    return;

  if (event.data.type && (event.data.type == "FROM_APP")) {
    console.log("[MSG] app.js : " + event.data.text);
    if (event.data.text == "refresh") {
      test();
    }
    // port.postMessage("Refreshed the Page");
  }
}, false);



/////////////////////////////////////////
//             Variables               //
/////////////////////////////////////////

// include(chrome.extension.getURL('index.json'));


/////////////////////////////////////////
//             Start Code              //
/////////////////////////////////////////

addApp();

function test() {
  alert("REFRESH THE PAGE")
}

function addApp() {
  var app = document.createElement("div");
  app.id = "TPOT_APP";
  app.setAttribute("w3-include-html", chrome.extension.getURL('app.html'));
  $("body").prepend(app);
  setTimeout(function() {
    includeHTML();
  }, 25);
  setTimeout(function() {
    function assignEventListeners() {
      document.getElementById("btn_insert").addEventListener("click",
        function() {
          window.postMessage({
            type: "FROM_CONTENT",
            text: "insert"
          }, "*");
        }, false);
    }
  }, 500);




  //  chrome.runtime.onMessage.addListener(
  //  function(message, callback) {
  //    if (message == “runContentScript”){
  //
  //    }
  // });
  // includeJS('jquery.js');
  // includeJS('app.js');
  // includeCSS('app.css');

  // Refresh Settings After DOM Loaded for App
}

function includeJS(file) {
  var script = document.createElement('script');
  script.onload = function() {
    //do stuff with the script
  };
  script.src = chrome.extension.getURL(file);
  script.type = "APP_JS";
  $("head").append(script); //or something of the likes
}

function includeCSS(file) {
  var style = document.createElement('script');
  style.onload = function() {
    //do stuff with the script
  };
  style.src = chrome.extension.getURL(file);
  style.id = "APP_CSS";
  $("head").append(style); //or something of the likes
}

function refreshApp() {

  // includeJS('jquery.js');
  // includeJS('app.js');
}

// function includeJS(file) {
//   var script = document.createElement('script');
//   script.type = "APP_JS";
//   script.src = chrome.extension.getURL(file);
//   script.onload = function() {
//     alert("script loaded");
//   };
//   $("head").prepend(script); //or something of the likes
// }




function includeHTML() {
  var z, i, elmnt, file, xhttp;
  /*loop through a collection of all HTML elements:*/
  z = document.getElementsByTagName("*");
  for (i = 0; i < z.length; i++) {
    elmnt = z[i];
    /*search for elements with a certain atrribute:*/
    file = elmnt.getAttribute("w3-include-html");
    if (file) {
      /*make an HTTP request using the attribute value as the file name:*/
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
          if (this.status == 200) {
            elmnt.innerHTML = this.responseText;
          }
          if (this.status == 404) {
            elmnt.innerHTML = "Page not found.";
          }
          /*remove the attribute, and call this function once more:*/
          elmnt.removeAttribute("w3-include-html");
          includeHTML();
        }
      }
      xhttp.open("GET", file, true);
      xhttp.send();
      /*exit the function:*/
      return;
    }
  }
}
