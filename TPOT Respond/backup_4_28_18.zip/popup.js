// alert('popup');
// 
// // Switching to New Active Tab
// chrome.tabs.onActivated.addListener(activeTab());
//
// function activeTab() {
//   alert('test!');
// }
//
//
//
// function isAppInjected() {
//   window.
// }
//
// function getActiveTab() {
//   chrome.tabs.query({
//     currentWindow: true,
//     active: true
//   }, function(tabs) {
//     console.log(tabs[0]);
//   });
//   return tabs[0];
// }
