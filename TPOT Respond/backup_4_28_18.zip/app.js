function test() {
  alert('I am here again!');
  toggle();
}
