const Colors = Object.freeze({
    RED: Symbol("red"),
    BLUE: Symbol("blue"),
    GREEN: Symbol("green"),
})