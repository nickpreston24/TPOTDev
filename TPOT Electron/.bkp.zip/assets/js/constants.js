const googleDriveUrl = 'https://drive.google.com/drive/folders/1qIp_1PI05UgXEmieM5RzwUvgshRt3Zcj'

module.exports = {
    googleDriveUrl
}