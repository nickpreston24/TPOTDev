const userGUI = {
    window_Height: '800px',
    window_Width: '1200px',
    header_Height: '45px',
    appbar_Width: '70px'
}

