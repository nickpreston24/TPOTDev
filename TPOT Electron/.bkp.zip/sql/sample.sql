SELECT rowid AS id, info
FROM user_info


